import './Common.css';

function Footer() {
  return (
    <div className="footer">
      <p>© 2025 Store Rating App. All rights reserved.</p>
    </div>
  );
}

export default Footer;
