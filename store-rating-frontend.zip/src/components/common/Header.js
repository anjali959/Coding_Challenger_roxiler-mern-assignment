import { Link } from 'react-router-dom';
import './Common.css';

function Header() {
  return (
    <div className="header">
      <h2>Store Rating Platform</h2>
      <div className="nav">
        <Link to="/">Home</Link> | <Link to="/login">Login</Link> | <Link to="/signup">Signup</Link>
      </div>
    </div>
  );
}

export default Header;
