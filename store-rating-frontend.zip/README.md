# Store Rating App
A full-stack store rating platform with role-based login.